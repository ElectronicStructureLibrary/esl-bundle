# libsmm_acc Notebooks

Notebooks for exploring data generated from auto-tuning and prediction.

**Requirements**
Python version required: python 3.6

Install all python packages required (if you do not want this project's requirements to interfere with your other Python projects, consider doing so in a [virtual environment](https://docs.python.org/3/tutorial/venv.html)), using

```bash
pip install -r requirements.txt
```

#### libsmm_acc predictive_modelling_features

The XML file `libsmm_acc_predictive_modelling_features.xml` can be opened in [www.draw.io](www.draw.io) to be edited.

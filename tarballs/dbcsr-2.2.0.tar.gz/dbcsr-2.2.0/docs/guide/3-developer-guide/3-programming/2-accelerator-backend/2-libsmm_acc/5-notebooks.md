title: Notebooks

{!./src/acc/libsmm_acc/notebooks/README.md!}

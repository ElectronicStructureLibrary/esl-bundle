title: OpenCL LIBSMM

{!./src/acc/opencl/smm/README.md!}

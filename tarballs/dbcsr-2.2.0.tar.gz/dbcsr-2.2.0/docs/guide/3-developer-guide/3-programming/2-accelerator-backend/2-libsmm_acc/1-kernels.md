title: Kernels

![kernel parameters and memory](|media|/images/libsmm_acc_parameters_and_memory.png){ width=50% }

{!./src/acc/libsmm_acc/kernels/README.md!}

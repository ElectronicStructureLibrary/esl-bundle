title: LIBSMM (CUDA/HIP)

{!./src/acc/libsmm_acc/README.md!}

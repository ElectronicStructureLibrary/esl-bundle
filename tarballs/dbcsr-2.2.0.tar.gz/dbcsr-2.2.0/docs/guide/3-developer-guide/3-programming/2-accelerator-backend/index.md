title: Accelerator Backend

{!./src/acc/README.md!}

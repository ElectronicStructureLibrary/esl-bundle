# flake8: noqa
with section("format"):
    separate_ctrl_name_with_space = True

#ifndef WRAPPER_h
#define WRAPPER_h

const int SIZE_wrp = 12;

#endif

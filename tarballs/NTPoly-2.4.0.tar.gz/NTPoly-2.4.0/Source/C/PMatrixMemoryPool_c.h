#ifndef DISTRIBUTEDMATRIXMEMORYPOOL_ch
#define DISTRIBUTEDMATRIXMEMORYPOOL_ch

void ConstructMatrixMemoryPool_p_wrp(int *ih_this, const int *ih_matrix);
void DestructMatrixMemoryPool_p_wrp(int *ih_this);

#endif

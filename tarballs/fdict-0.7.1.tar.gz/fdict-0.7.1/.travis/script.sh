#!/bin/bash

cd obj
make test

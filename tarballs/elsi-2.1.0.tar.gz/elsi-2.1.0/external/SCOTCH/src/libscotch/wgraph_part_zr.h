/*
**  The function prototypes.
*/

#ifndef WGRAPH_PART_ZR
#define static
#endif

int                         wgraphPartZr    (Wgraph * const);

#undef static

#ifndef MATRIXMEMORYPOOL_ch
#define MATRIXMEMORYPOOL_ch

void ConstructMatrixMemoryPool_lr_wrp(int *ih_this, const int *columns,
                                      const int *rows);
void DestructMatrixMemoryPool_lr_wrp(int *ih_this);

void ConstructMatrixMemoryPool_lc_wrp(int *ih_this, const int *columns,
                                      const int *rows);
void DestructMatrixMemoryPool_lc_wrp(int *ih_this);

#endif

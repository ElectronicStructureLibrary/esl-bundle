#!/bin/sh

# Helper script to install the full range of flavors of libgridxc (assuming libxc functionality).
# It uses the '--enable-multiconfig' feature to tag the different flavors appropriately in the
# installation directory.

# These variables should be defined, either through environmental variables or as script arguments.

#GRIDXC_PREFIX=/tmp/GXC_MULTI

#CC=gcc
#FC=gfortran
#MPIFC=mpif90
#MPICC=mpicc

#LIBXC_ROOT  # Installation location of libxc.
#MPI_ROOT    # Installation location of the mpi framework.

# ensure libtool does not grab a wrong env-var
unset F77
unset F90

##########
# Double #
#   MPI  #
##########
rm -rf build_dp_mpi; mkdir build_dp_mpi; cd build_dp_mpi
FC=$MPIFC CC=$MPICC ../configure --enable-multiconfig  --with-mpi=${MPI_ROOT} --with-libxc=${LIBXC_ROOT}  --prefix=${GRIDXC_PREFIX}
[ $? -ne 0 ] && return 1
make
[ $? -ne 0 ] && return 1
make check
[ $? -ne 0 ] && return 1
make install
[ $? -ne 0 ] && return 1
cd ..

##########
# Double #
##########

rm -rf build_dp; mkdir build_dp; cd build_dp
../configure --enable-multiconfig --without-mpi --with-libxc=${LIBXC_ROOT}  --prefix=${GRIDXC_PREFIX}
[ $? -ne 0 ] && return 1
make
[ $? -ne 0 ] && return 1
make check
[ $? -ne 0 ] && return 1
make install
[ $? -ne 0 ] && return 1
cd ..

##########
# Single #
#   MPI  #
##########

rm -rf build_sp_mpi; mkdir build_sp_mpi; cd build_sp_mpi
FC=$MPIFC CC=$MPICC ../configure --enable-multiconfig  --with-mpi=${MPI_ROOT} --enable-single-precision --with-libxc=${LIBXC_ROOT}  --prefix=${GRIDXC_PREFIX}
[ $? -ne 0 ] && return 1
make
[ $? -ne 0 ] && return 1
make check
[ $? -ne 0 ] && return 1
make install
[ $? -ne 0 ] && return 1
cd ..

##########
# Single #
##########

rm -rf build_sp ; mkdir build_sp; cd build_sp
../configure --enable-multiconfig --without-mpi --enable-single-precision --with-libxc=${LIBXC_ROOT}  --prefix=${GRIDXC_PREFIX}
[ $? -ne 0 ] && return 1
make
[ $? -ne 0 ] && return 1
make check
[ $? -ne 0 ] && return 1
make install
[ $? -ne 0 ] && return 1
cd ..



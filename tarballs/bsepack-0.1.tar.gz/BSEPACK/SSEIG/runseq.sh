#!/bin/sh

./stest_ssmv.exe
./dtest_ssmv.exe
./stest_ssmm.exe
./dtest_ssmm.exe
./stest_ssr2.exe
./dtest_ssr2.exe
./stest_ssr2k.exe
./dtest_ssr2k.exe
./stest_sstd2.exe
./dtest_sstd2.exe
./stest_sstrd.exe
./dtest_sstrd.exe

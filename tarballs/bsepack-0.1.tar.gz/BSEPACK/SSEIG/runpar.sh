#!/bin/sh

MPIRUN=mpirun
NP=-np

$MPIRUN $NP 1 ./pstest_ssmv.exe
$MPIRUN $NP 1 ./pdtest_ssmv.exe
$MPIRUN $NP 1 ./pstest_ssr2k.exe
$MPIRUN $NP 1 ./pdtest_ssr2k.exe
$MPIRUN $NP 1 ./pstest_sstd2.exe
$MPIRUN $NP 1 ./pdtest_sstd2.exe
$MPIRUN $NP 1 ./pstest_sstrd.exe
$MPIRUN $NP 1 ./pdtest_sstrd.exe

$MPIRUN $NP 13 ./pstest_ssmv.exe
$MPIRUN $NP 13 ./pdtest_ssmv.exe
$MPIRUN $NP 13 ./pstest_ssr2k.exe
$MPIRUN $NP 13 ./pdtest_ssr2k.exe
$MPIRUN $NP 13 ./pstest_sstd2.exe
$MPIRUN $NP 13 ./pdtest_sstd2.exe
$MPIRUN $NP 13 ./pstest_sstrd.exe
$MPIRUN $NP 13 ./pdtest_sstrd.exe

#include <stdio.h>

#define MIN(x, y) ((x) < (y) ? (x) : (y))

void sprnmat_(int *m, int *n, float A[], int *ldA, char *name, int len)
{
    int i, j;
    char tmp[16];

    for (i = 0; i < MIN(len, 15); i++)
        tmp[i] = name[i];
    tmp[i] = '\0';
    printf("%s=zeros(%d,%d);\n", tmp, *m, *n);
    for (j = 0; j < *n; j++)
    for (i = 0; i < *m; i++)
        printf("%s(%d,%d) = %.7e;\n", tmp, i+1, j+1, A[i + j*(*ldA)]);
    fflush(stdout);
}

void dprnmat_(int *m, int *n, double A[], int *ldA, char *name, int len)
{
    int i, j;
    char tmp[16];

    for (i = 0; i < MIN(len, 15); i++)
        tmp[i] = name[i];
    tmp[i] = '\0';

    printf("%s=zeros(%d,%d);\n", tmp, *m, *n);
    for (j = 0; j < *n; j++)
    for (i = 0; i < *m; i++)
        printf("%s(%d,%d) = %.16e;\n", tmp, i+1, j+1, A[i + j*(*ldA)]);
    fflush(stdout);
}

void sprnvec_(int *n, float x[], int *incx, char *name, int len)
{
    int i;
    char tmp[16];

    for (i = 0; i < MIN(len, 15); i++)
        tmp[i] = name[i];
    tmp[i] = '\0';

    if (*incx < 0)
        x = x - (*n-1)*(*incx);

    printf("%s=zeros(%d,1);\n", tmp, *n);
    for (i = 0; i < *n; i++)
        printf("%s(%d) = %.7e;\n", tmp, i+1, x[i*(*incx)]);
    fflush(stdout);
}

void dprnvec_(int *n, double x[], int *incx, char *name, int len)
{
    int i;
    char tmp[16];

    for (i = 0; i < MIN(len, 15); i++)
        tmp[i] = name[i];
    tmp[i] = '\0';

    if (*incx < 0)
        x = x - (*n-1)*(*incx);

    printf("%s=zeros(%d,1);\n", tmp, *n);
    for (i = 0; i < *n; i++)
        printf("%s(%d) = %.16e;\n", tmp, i+1, x[i*(*incx)]);
    fflush(stdout);
}

#!/bin/sh

MPIRUN=mpirun
NP=-np

rm -f summary_sseig.txt
rm -f summary_bsepack.txt
rm -f summary.txt

cd ../SSEIG/
./runseq.sh >> ../TESTING/summary_sseig.txt
./runpar.sh >> ../TESTING/summary_sseig.txt
cd ../TESTING/

$MPIRUN $NP 1 ./dtest.exe >> summary_bsepack.txt
$MPIRUN $NP 1 ./ztest.exe >> summary_bsepack.txt
$MPIRUN $NP 13 ./dtest.exe >> summary_bsepack.txt
$MPIRUN $NP 13 ./ztest.exe >> summary_bsepack.txt

cat summary_sseig.txt summary_bsepack.txt > summary.txt
cat summary.txt

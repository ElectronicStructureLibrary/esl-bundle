Wannier90 autodoc
=================

The auto-generated documentation is build using FORD (https://github.com/cmacmackin/ford/wiki).

To create the documentation, install FORD and run

    ford project.md
    
The main page of the documentation will be ./build/index.html

For working on the autodoc, you can use

    ford fast.md

which will not create the graphs and search indices, and thus be faster. The main page will then be ./build_fast/index.html

Reference file run from the example (in program mode, not in library mode)
to be used as a reference for the results

Moreover, the results_ref.dat is instead produced with the output of the code (it has the same content)

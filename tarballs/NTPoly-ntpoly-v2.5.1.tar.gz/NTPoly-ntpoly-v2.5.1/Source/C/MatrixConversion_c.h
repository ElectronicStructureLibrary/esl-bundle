#ifndef MATRIXCONVERSIONMODULE_ch
#define MATRIXCONVERSIONMODULE_ch

void SnapMatrixToSparsityPattern_wrp(int *ih_matA, const int *ih_matB);

#endif
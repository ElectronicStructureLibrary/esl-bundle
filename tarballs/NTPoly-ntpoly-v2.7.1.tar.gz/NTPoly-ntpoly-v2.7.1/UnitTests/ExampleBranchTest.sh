# If you want to define a test for your branch, do it like this.

BRANCHTEST="test_psmatrix.TestPSMatrix.test_read"

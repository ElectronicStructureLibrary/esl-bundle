#ifndef ANALYSIS_ch
#define ANALYSIS_ch

void PivotedCholeskyDecomposition_wrp(const int *ih_MatA, int *ih_MatL,
                                      const int *rank_in,
                                      const int *ih_solver_parameters);
#endif

// The stored build config

